function changeLampColor() {
	if(this.id == "redBtn"){
		document.getElementsByClassName("lamp")[0].style.backgroundColor = 'red';
	}
	else if(this.id == "blueBtn"){
		document.getElementsByClassName("lamp")[0].style.backgroundColor = 'blue';
	}
	else if(this.id == "greenBtn"){
		document.getElementsByClassName("lamp")[0].style.backgroundColor = 'green';
	}
	else {
		document.getElementsByClassName("lamp")[0].style.backgroundColor = 'grey';
	}
	document.getElementById("notification").innerHTML = parseInt(document.getElementById("notification").innerHTML) + 1;
}

function toggleOff() {
	document.getElementsByClassName("lamp")[0].classList.toggle('lamp-off');
	document.getElementById("notification").innerHTML = parseInt(document.getElementById("notification").innerHTML) + 1;
}

document.getElementById("powerBtn").onclick = toggleOff;
document.getElementById("redBtn").onclick = changeLampColor;
document.getElementById("blueBtn").onclick = changeLampColor;
document.getElementById("greenBtn").onclick = changeLampColor;
document.getElementById("customBtn").onclick = changeLampColor;